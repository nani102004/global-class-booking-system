package com.globallearning.booking.controller;


import com.globallearning.booking.dto.BookingResponse;
import com.globallearning.booking.dto.CancelBookingResponse;
import com.globallearning.booking.dto.CreateParentRequest;
import com.globallearning.booking.dto.ParentOfferingResponse;
import com.globallearning.booking.entity.Parent;
import com.globallearning.booking.service.BookingService;
import com.globallearning.booking.service.ParentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/parents")
public class ParentController {

    private final ParentService parentService;
    private final BookingService bookingService;

    public ParentController(ParentService parentService, BookingService bookingService) {
        this.parentService = parentService;
        this.bookingService = bookingService;
    }

    @PostMapping
    public ResponseEntity<Parent> createParent(
            @Valid @RequestBody CreateParentRequest request) {

        Parent parent = parentService.createParent(request);

        return ResponseEntity.status(HttpStatus.CREATED).body(parent);
    }

    @GetMapping("/{parentId}/offerings/available")
    public ResponseEntity<List<ParentOfferingResponse>> getAvailableOfferings(
            @PathVariable Long parentId) {

        List<ParentOfferingResponse> offerings =
                parentService.getAvailableOfferings(parentId);

        return ResponseEntity.ok(offerings);
    }

    @PostMapping("/{parentId}/offerings/{offeringId}/bookings")
    public ResponseEntity<BookingResponse> bookOffering(
            @PathVariable Long parentId,
            @PathVariable Long offeringId) {

        BookingResponse bookingResponse =
                bookingService.bookOffering(parentId, offeringId);

        return ResponseEntity.status(HttpStatus.CREATED).body(bookingResponse);
    }

    @GetMapping("/{parentId}/bookings")
    public ResponseEntity<List<BookingResponse>> getBookings(
            @PathVariable Long parentId) {

        List<BookingResponse> bookings = bookingService.getBookings(parentId);

        return ResponseEntity.ok(bookings);
    }

    @PutMapping("/{parentId}/bookings/{bookingId}/cancel")
    public ResponseEntity<CancelBookingResponse> cancelBooking(
            @PathVariable Long parentId,
            @PathVariable Long bookingId) {

        CancelBookingResponse response = bookingService.cancelBooking(parentId, bookingId);
        return ResponseEntity.ok(response);
    }


}