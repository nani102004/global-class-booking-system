package com.globallearning.booking.controller;


import com.globallearning.booking.dto.AddSessionsRequest;
import com.globallearning.booking.dto.CreateOfferingRequest;
import com.globallearning.booking.dto.CreateTeacherRequest;
import com.globallearning.booking.dto.TeacherOfferingResponse;
import com.globallearning.booking.entity.Offering;
import com.globallearning.booking.entity.Session;
import com.globallearning.booking.entity.Teacher;
import com.globallearning.booking.service.OfferingService;
import com.globallearning.booking.service.SessionService;
import com.globallearning.booking.service.TeacherService;
import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/teachers")
public class TeacherController {

    private final TeacherService teacherService;
    private final OfferingService offeringService;
    private final SessionService sessionService;

    public TeacherController(TeacherService teacherService, OfferingService offeringService, SessionService sessionService) {
        this.teacherService = teacherService;
        this.offeringService = offeringService;
        this.sessionService = sessionService;
    }

    @PostMapping
    public ResponseEntity<Teacher> createTeacher(
            @Valid @RequestBody CreateTeacherRequest request
    ) {
        Teacher teacher = teacherService.createTeacher(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(teacher);
    }

    @PostMapping("/offerings")
    public ResponseEntity<Offering> createOffering(
            @Valid @RequestBody CreateOfferingRequest request
    ) {
        Offering offering = offeringService.createOffering(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(offering);
    }

    @PostMapping("/offerings/{offeringId}/sessions")
    public ResponseEntity<List<Session>> addSessions(
            @PathVariable Long offeringId,
            @Valid @RequestBody AddSessionsRequest request) {

        List<Session> sessions = sessionService.addSessions(offeringId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(sessions);
    }

    @GetMapping("/{teacherId}/offerings")
    public ResponseEntity<List<TeacherOfferingResponse>>  getTeacherOfferings(
            @PathVariable Long teacherId) {

        List<TeacherOfferingResponse> offerings =
                offeringService.getTeacherUpcomingOfferings(teacherId);

        return ResponseEntity.ok(offerings);
    }

}