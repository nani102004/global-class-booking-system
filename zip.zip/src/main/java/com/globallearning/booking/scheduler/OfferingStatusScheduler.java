package com.globallearning.booking.scheduler;

import com.globallearning.booking.entity.Offering;
import com.globallearning.booking.enums.OfferingStatus;
import com.globallearning.booking.repository.OfferingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Slf4j
@Component
public class OfferingStatusScheduler {

    private final OfferingRepository offeringRepository;

    public OfferingStatusScheduler(OfferingRepository offeringRepository) {
        this.offeringRepository = offeringRepository;
    }

    @Scheduled(cron = "0 * * * * *")
    @Transactional
    public void markOfferingsInProgress() {
        Instant now = Instant.now();

        List<Offering> offerings = offeringRepository.findOfferingsToMarkInProgress(
                List.of(OfferingStatus.ACTIVE, OfferingStatus.CLOSED),
                now
        );

        for (Offering offering : offerings) {
            offering.setStatus(OfferingStatus.IN_PROGRESS);
        }

        if (!offerings.isEmpty()) {
            offeringRepository.saveAll(offerings);
            log.info("Marked {} offerings as IN_PROGRESS", offerings.size());
        }
    }

    @Scheduled(cron = "30 * * * * *")
    @Transactional
    public void markOfferingsCompleted() {
        Instant now = Instant.now();

        List<Offering> offerings = offeringRepository.findOfferingsToMarkCompleted(
                OfferingStatus.IN_PROGRESS,
                now
        );

        for (Offering offering : offerings) {
            offering.setStatus(OfferingStatus.COMPLETED);
        }

        if (!offerings.isEmpty()) {
            offeringRepository.saveAll(offerings);
            log.info("Marked {} offerings as COMPLETED", offerings.size());
        }
    }
}