package com.globallearning.booking.service;

import com.globallearning.booking.dto.BookingResponse;
import com.globallearning.booking.dto.CancelBookingResponse;
import com.globallearning.booking.entity.Booking;
import com.globallearning.booking.entity.Parent;
import com.globallearning.booking.entity.Offering;
import com.globallearning.booking.entity.Session;
import com.globallearning.booking.enums.BookingStatus;
import com.globallearning.booking.enums.OfferingStatus;
import com.globallearning.booking.exception.BookingException;
import com.globallearning.booking.exception.ResourceNotFoundException;
import com.globallearning.booking.repository.BookingRepository;
import com.globallearning.booking.repository.OfferingRepository;
import com.globallearning.booking.repository.ParentRepository;

import com.globallearning.booking.util.ResponseMapper;
import com.globallearning.booking.util.SessionTimeUtil;
import com.globallearning.booking.util.TimezoneValidator;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.stereotype.Service;

import java.time.Instant;

import java.time.ZoneId;
import java.util.List;

@Service
public class BookingService {

    private final ParentRepository parentRepository;
    private final OfferingRepository offeringRepository;
    private final BookingRepository bookingRepository;

    public BookingService(ParentRepository parentRepository, OfferingRepository offeringRepository, BookingRepository bookingRepository) {
        this.parentRepository = parentRepository;
        this.offeringRepository = offeringRepository;
        this.bookingRepository = bookingRepository;
    }

    @Transactional
    public BookingResponse bookOffering(Long parentId, Long offeringId) {
        Parent parent = parentRepository.findById(parentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Parent not found with id: " + parentId,
                        "Parent not found"
                ));

        Offering offering = offeringRepository.findById(offeringId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Offering not found with id: " + offeringId,
                        "Offering not found"
                ));

        String failureMessage = validateBooking(parent, offering);

        if (failureMessage != null) {
            saveBooking(parent, offering, BookingStatus.FAILED);

            throw new BookingException(
                    "Booking failed for parentId: " + parentId
                            + ", offeringId: " + offeringId
                            + ". Reason: " + failureMessage,
                    failureMessage
            );
        }

        Booking confirmedBooking = saveBooking(parent, offering, BookingStatus.CONFIRMED);
        updateOfferingStatusIfCapacityFull(offering);

        return mapToResponse(confirmedBooking);
    }

    @Transactional(readOnly = true)
    public List<BookingResponse> getBookings(Long parentId) {
        Parent parent = parentRepository.findById(parentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Parent not found with id: " + parentId,
                        "Parent not found"
                ));

        ZoneId parentZoneId = ZoneId.of(parent.getTimezone());

        return bookingRepository.findByParentId(parentId)
                .stream()
                .map(booking -> mapToResponse(
                        booking,
                        getBookingMessage(booking),
                        parentZoneId
                ))
                .toList();
    }

    @Transactional
    public CancelBookingResponse cancelBooking(Long parentId, Long bookingId) {
        Booking booking = bookingRepository.findByIdAndParentId(bookingId, parentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Booking not found with id: " + bookingId + " for parent id: " + parentId,
                        "Booking not found"
                ));

        if (booking.getStatus() != BookingStatus.CONFIRMED) {
            throw new BookingException(
                    "Only confirmed bookings can be cancelled. Booking id: " + bookingId,
                    "Only confirmed bookings can be cancelled"
            );
        }

        booking.setStatus(BookingStatus.CANCELLED);

        Offering offering = booking.getOffering();

        if (offering.getStatus() == OfferingStatus.CLOSED) {
            offering.setStatus(OfferingStatus.ACTIVE);
            offeringRepository.save(offering);
        }

        Booking savedBooking = bookingRepository.save(booking);

        return CancelBookingResponse.builder()
                .bookingId(savedBooking.getId())
                .parentId(savedBooking.getParent().getId())
                .offeringId(savedBooking.getOffering().getId())
                .status(savedBooking.getStatus())
                .message("Booking cancelled successfully")
                .bookedAt(savedBooking.getBookedAt())
                .build();
    }

    private String validateBooking(Parent parent, Offering offering) {
        if (offering.getStatus() == OfferingStatus.CANCELLED) {
            return "Offering is cancelled by teacher";
        }

        if (offering.getStatus() == OfferingStatus.COMPLETED) {
            return "Offering is already completed";
        }

        if (offering.getStatus() == OfferingStatus.IN_PROGRESS) {
            return "Offering has already started";
        }

        if (offering.getStatus() == OfferingStatus.DRAFT) {
            return "Offering does not have sessions yet";
        }

        if (offering.getStatus() == OfferingStatus.CLOSED) {
            return "Offering capacity is full";
        }

        if (bookingRepository.existsByParentIdAndOfferingIdAndStatus(
                parent.getId(),
                offering.getId(),
                BookingStatus.CONFIRMED
        )) {
            return "Candidate already registered for this offering";
        }

        long confirmedBookings = bookingRepository.countByOfferingIdAndStatus(
                offering.getId(),
                BookingStatus.CONFIRMED
        );

        if (confirmedBookings >= offering.getCapacity()) {
            return "Offering capacity is full";
        }

        if (hasSessionConflict(parent.getId(), offering,Instant.now())) {
            return "Session time overlaps with an existing confirmed booking";
        }

        return null;
    }

    private boolean hasSessionConflict(Long parentId, Offering newOffering,Instant now) {
        List<Booking> confirmedBookings = bookingRepository.findByParentIdAndStatus(
                parentId,
                BookingStatus.CONFIRMED
        );


        List<Session> existingFutureSessions = confirmedBookings.stream()
                .flatMap(booking -> booking.getOffering().getSessions().stream())
                .filter(session -> session.getEndTimeUtc().isAfter(now))
                .toList();

        return SessionTimeUtil.hasOverlap(existingFutureSessions, newOffering.getSessions());
    }

    private Booking saveBooking(
            Parent parent,
            Offering offering,
            BookingStatus status
    ) {
        Booking booking = Booking.builder()
                .parent(parent)
                .offering(offering)
                .status(status)
                .bookedAt(Instant.now())
                .build();

        return bookingRepository.save(booking);
    }

    private void updateOfferingStatusIfCapacityFull(Offering offering) {
        long confirmedBookings = bookingRepository.countByOfferingIdAndStatus(
                offering.getId(),
                BookingStatus.CONFIRMED
        );

        if (confirmedBookings >= offering.getCapacity()) {
            offering.setStatus(OfferingStatus.CLOSED);
            offeringRepository.save(offering);
        }
    }

    private BookingResponse mapToResponse(
            Booking booking
    ) {
        ZoneId parentZoneId = TimezoneValidator.validateAndGetZoneId(booking.getParent().getTimezone());
        return mapToResponse(booking, "Booking confirmed successfully", parentZoneId);
    }

    private BookingResponse mapToResponse(
            Booking booking,
            String message,
            ZoneId parentZoneId
    ) {
        Offering offering = booking.getOffering();

        return BookingResponse.builder()
                .bookingId(booking.getId())
                .parentId(booking.getParent().getId())
                .offeringId(offering.getId())
                .offeringTitle(offering.getTitle())
                .courseTitle(offering.getCourse().getTitle())
                .status(booking.getStatus())
                .message(message)
                .bookedAt(booking.getBookedAt())
                .sessions(ResponseMapper.toParentSessionResponses(offering.getSessions(), parentZoneId))
                .build();
    }

    private String getBookingMessage(Booking booking) {
        if (booking.getStatus() == BookingStatus.CONFIRMED) {
            return "Booking confirmed successfully";
        }

        if (booking.getStatus() == BookingStatus.FAILED) {
            return "Booking failed";
        }

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            return "Booking cancelled by candidate";
        }

        return "Booking status unavailable";
    }
}