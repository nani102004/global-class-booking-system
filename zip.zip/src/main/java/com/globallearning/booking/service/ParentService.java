package com.globallearning.booking.service;

import com.globallearning.booking.dto.CreateParentRequest;
import com.globallearning.booking.dto.ParentOfferingResponse;
import com.globallearning.booking.entity.Booking;
import com.globallearning.booking.entity.Offering;
import com.globallearning.booking.entity.Parent;
import com.globallearning.booking.entity.Session;
import com.globallearning.booking.enums.BookingStatus;
import com.globallearning.booking.enums.OfferingStatus;
import com.globallearning.booking.exception.ResourceNotFoundException;
import com.globallearning.booking.repository.BookingRepository;
import com.globallearning.booking.repository.OfferingRepository;
import com.globallearning.booking.repository.ParentRepository;
import com.globallearning.booking.util.ResponseMapper;
import com.globallearning.booking.util.SessionTimeUtil;
import com.globallearning.booking.util.TimezoneValidator;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ParentService {

    private final ParentRepository parentRepository;
    private final OfferingRepository offeringRepository;
    private final BookingRepository bookingRepository;

    public ParentService(ParentRepository parentRepository, OfferingRepository offeringRepository, BookingRepository bookingRepository) {
        this.parentRepository = parentRepository;
        this.offeringRepository = offeringRepository;
        this.bookingRepository = bookingRepository;
    }

    public Parent createParent(CreateParentRequest request) {
        TimezoneValidator.validateAndGetZoneId(request.getTimezone());

        Parent parent = Parent.builder()
                .name(request.getName())
                .email(request.getEmail())
                .timezone(request.getTimezone())
                .createdAt(LocalDateTime.now())
                .build();

        return parentRepository.save(parent);
    }

    @Transactional(readOnly = true)
    public List<ParentOfferingResponse> getAvailableOfferings(Long parentId) {
        Parent parent = parentRepository.findById(parentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Parent not found with id: " + parentId,
                        "Parent not found"
                ));

        ZoneId parentZoneId = ZoneId.of(parent.getTimezone());

        List<Booking> confirmedBookings =
                bookingRepository.findByParentIdAndStatus(parentId, BookingStatus.CONFIRMED);

        Set<Long> alreadyBookedOfferingIds = confirmedBookings.stream()
                .map(booking -> booking.getOffering().getId())
                .collect(Collectors.toSet());

        List<Session> confirmedFutureSessions = confirmedBookings.stream()
                .flatMap(booking -> booking.getOffering().getSessions().stream())
                .filter(session -> session.getEndTimeUtc().isAfter(Instant.now()))
                .toList();

        return offeringRepository.findByStatus(OfferingStatus.ACTIVE)
                .stream()
                .filter(offering -> !alreadyBookedOfferingIds.contains(offering.getId()))
                .filter(offering -> !SessionTimeUtil.hasOverlap(
                    confirmedFutureSessions,
                    offering.getSessions())
                )
                .map(offering -> mapToParentOfferingResponse(offering, parentZoneId))
                .toList();
    }


    private ParentOfferingResponse mapToParentOfferingResponse(
            Offering offering,
            ZoneId parentZoneId
    ) {
        long confirmedBookings = bookingRepository.countByOfferingIdAndStatus(
                offering.getId(),
                BookingStatus.CONFIRMED
        );

        int remainingSeats = offering.getCapacity() - (int) confirmedBookings;

        return ParentOfferingResponse.builder()
                .offeringId(offering.getId())
                .offeringTitle(offering.getTitle())
                .courseId(offering.getCourse().getId())
                .courseTitle(offering.getCourse().getTitle())
                .teacherName(offering.getTeacher().getName())
                .remainingSeats(remainingSeats)
                .sessions(ResponseMapper.toParentSessionResponses(
                        offering.getSessions(),
                        parentZoneId
                ))
                .build();
    }
}