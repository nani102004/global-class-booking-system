package com.globallearning.booking.service;

import com.globallearning.booking.dto.AddSessionRequest;
import com.globallearning.booking.dto.AddSessionsRequest;
import com.globallearning.booking.entity.Offering;
import com.globallearning.booking.entity.Session;
import com.globallearning.booking.enums.OfferingStatus;
import com.globallearning.booking.exception.InvalidInputException;
import com.globallearning.booking.exception.ResourceNotFoundException;
import com.globallearning.booking.repository.OfferingRepository;
import com.globallearning.booking.repository.SessionRepository;
import com.globallearning.booking.util.SessionTimeUtil;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@Service
public class SessionService {

    private final OfferingRepository offeringRepository;
    private final SessionRepository sessionRepository;

    public SessionService(OfferingRepository offeringRepository, SessionRepository sessionRepository) {
        this.offeringRepository = offeringRepository;
        this.sessionRepository = sessionRepository;
    }

    @Transactional
    public List<Session> addSessions(Long offeringId, AddSessionsRequest request) {
        Offering offering = offeringRepository.findById(offeringId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Offering not found with id: " + offeringId,
                        "Offering not found"
                ));

        ZoneId offeringZoneId = ZoneId.of(offering.getTimezone());
        Instant now = Instant.now();

        List<Session> newSessions = buildAndValidateSessions(offering, request, offeringZoneId, now);

        validateTeacherSessionOverlap(
                offering.getTeacher().getId(),
                newSessions,
                now
        );

        List<Session> savedSessions = sessionRepository.saveAll(newSessions);

        offering.setStatus(OfferingStatus.ACTIVE);
        offeringRepository.save(offering);

        return savedSessions;
    }

    private List<Session> buildAndValidateSessions(
            Offering offering,
            AddSessionsRequest request,
            ZoneId offeringZoneId,
            Instant now
    ) {
        List<Session> newSessions = new ArrayList<>();

        for (AddSessionRequest sessionRequest : request.getSessions()) {
            Instant startTimeUtc = sessionRequest.getStartTime()
                    .atZone(offeringZoneId)
                    .toInstant();

            Instant endTimeUtc = sessionRequest.getEndTime()
                    .atZone(offeringZoneId)
                    .toInstant();

            validateSessionTime(startTimeUtc, endTimeUtc, now);

            Session session = Session.builder()
                    .offering(offering)
                    .teacher(offering.getTeacher())
                    .startTimeUtc(startTimeUtc)
                    .endTimeUtc(endTimeUtc)
                    .createdAt(LocalDateTime.now())
                    .build();

            newSessions.add(session);
        }

        if (SessionTimeUtil.hasOverlap(newSessions)) {
            throw new InvalidInputException(
                    "New sessions overlap with each other",
                    "Sessions should not overlap with each other"
            );
        }

        return newSessions;
    }

    private void validateSessionTime(Instant startTimeUtc, Instant endTimeUtc, Instant now) {
        if (!endTimeUtc.isAfter(startTimeUtc)) {
            throw new InvalidInputException(
                    "Session end time must be after start time",
                    "Session end time must be after start time"
            );
        }

        if (startTimeUtc.isBefore(now)) {
            throw new InvalidInputException(
                    "Session start time is in the past",
                    "Session timing should not be in the past"
            );
        }
    }

    private void validateTeacherSessionOverlap(
            Long teacherId,
            List<Session> newSessions,
            Instant now
    ) {
        List<Session> existingFutureSessions =
                sessionRepository.findFutureSessionsByTeacherId(teacherId, now);

        if (SessionTimeUtil.hasOverlap(existingFutureSessions, newSessions)) {
            throw new InvalidInputException(
                    "Teacher has overlapping sessions",
                    "Teacher has another session during this time"
            );
        }
    }
}