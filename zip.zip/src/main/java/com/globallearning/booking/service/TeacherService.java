package com.globallearning.booking.service;

import com.globallearning.booking.dto.CreateTeacherRequest;
import com.globallearning.booking.entity.Teacher;
import com.globallearning.booking.repository.TeacherRepository;
import com.globallearning.booking.util.TimezoneValidator;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class TeacherService {

    private final TeacherRepository teacherRepository;

    public TeacherService(TeacherRepository teacherRepository) {
        this.teacherRepository = teacherRepository;
    }

    public Teacher createTeacher(CreateTeacherRequest request) {
        TimezoneValidator.validateAndGetZoneId(request.getTimezone());

        Teacher teacher = Teacher.builder()
                .name(request.getName())
                .email(request.getEmail())
                .timezone(request.getTimezone())
                .createdAt(LocalDateTime.now())
                .build();

        return teacherRepository.save(teacher);
    }
}