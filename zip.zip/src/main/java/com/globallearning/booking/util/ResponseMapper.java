package com.globallearning.booking.util;


import com.globallearning.booking.dto.ParentSessionResponse;
import com.globallearning.booking.dto.TeacherSessionResponse;
import com.globallearning.booking.entity.Session;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Comparator;
import java.util.List;

public final class ResponseMapper {

    private ResponseMapper() {
    }

    public static List<ParentSessionResponse> toParentSessionResponses(
            List<Session> sessions,
            ZoneId zoneId
    ) {
        return sessions.stream()
                .sorted(Comparator.comparing(Session::getStartTimeUtc))
                .map(session -> ParentSessionResponse.builder()
                        .sessionId(session.getId())
                        .startTime(LocalDateTime.ofInstant(session.getStartTimeUtc(), zoneId))
                        .endTime(LocalDateTime.ofInstant(session.getEndTimeUtc(), zoneId))
                        .build())
                .toList();
    }

    public static List<TeacherSessionResponse> toTeacherSessionResponses(
            List<Session> sessions,
            ZoneId zoneId,
            Instant now
    ) {
        return sessions.stream()
                .filter(session -> session.getEndTimeUtc().isAfter(now))
                .sorted(Comparator.comparing(Session::getStartTimeUtc))
                .map(session -> TeacherSessionResponse.builder()
                        .sessionId(session.getId())
                        .startTime(LocalDateTime.ofInstant(session.getStartTimeUtc(), zoneId))
                        .endTime(LocalDateTime.ofInstant(session.getEndTimeUtc(), zoneId))
                        .build())
                .toList();
    }

}