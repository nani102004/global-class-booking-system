package com.globallearning.booking.util;

import com.globallearning.booking.entity.Session;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class SessionTimeUtil {

    private SessionTimeUtil() {
    }

    public static boolean hasOverlap(List<Session> sessions) {
        List<Session> sortedSessions = new ArrayList<>(sessions);
        sortedSessions.sort(Comparator.comparing(Session::getStartTimeUtc));

        for (int i = 1; i < sortedSessions.size(); i++) {
            Session previous = sortedSessions.get(i - 1);
            Session current = sortedSessions.get(i);

            if (previous.getEndTimeUtc().isAfter(current.getStartTimeUtc())) {
                return true;
            }
        }

        return false;
    }

    public static boolean hasOverlap(List<Session> existingSessions, List<Session> newSessions) {
        List<Session> allSessions = new ArrayList<>();
        allSessions.addAll(existingSessions);
        allSessions.addAll(newSessions);
        return hasOverlap(allSessions);
    }

    public static boolean hasStarted(List<Session> sessions, Instant now) {
        return sessions.stream()
                .anyMatch(session -> !session.getStartTimeUtc().isAfter(now));
    }
}