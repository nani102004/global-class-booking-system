package com.globallearning.booking.util;

import com.globallearning.booking.exception.InvalidInputException;

import java.time.ZoneId;

public final class TimezoneValidator {

    private TimezoneValidator() {
    }

    public static ZoneId validateAndGetZoneId(String timezone) {
        try {
            return ZoneId.of(timezone);
        } catch (Exception ex) {
            throw new InvalidInputException(
                    "Invalid timezone provided: " + timezone,
                    "Invalid timezone"
            );
        }
    }
}